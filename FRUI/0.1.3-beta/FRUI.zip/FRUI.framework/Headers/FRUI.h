//
//  FRUI.h
//  FRUI
//
//  Created by James Go on 6/12/19.
//  Copyright © 2019 James Go. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for FRUI.
FOUNDATION_EXPORT double FRUIVersionNumber;

//! Project version string for FRUI.
FOUNDATION_EXPORT const unsigned char FRUIVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <FRUI/PublicHeader.h>


