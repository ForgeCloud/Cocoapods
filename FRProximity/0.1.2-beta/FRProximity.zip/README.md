# ForgeRock iOS SDK
ForgeRock iOS SDK is a toolkit that allows developers communicate efficiently with ForgeRock Platform and ForgeRock Identity Cloud.

## Release Status
SDK is **currently still in development** and scheduling for Beta release in October, 2019. Please note that SDK's interfaces, functionalities, and designs may change at any time prior to the official release.

## Requirements
* iOS 10.0 and above (temporarily)
* Xcode 10.x
* Swift 5.x or Objective-C

## Installation
See below options for SDK installation
### Cocoapods
TBD
### Carthage
TBD
### Swift Package Manager
TBD

## Prerequisites
In order to use the SDK, it is mandatory to have properly set, and working version of Platform (ForgeRock OpenAM, OpenIDM, and OpenDJ), and/or ForgeRock Identity Cloud tenant.

## Repository Structure

### FRAuth
FRAuth project is a XCode SDK project for any authentication/authorization functionalities around ForgeRock Platform and ForgeRock Identity Cloud. FRAuth SDK currently supports AuthTree functionalities, and limited scope of OAuth2.

### FRUI
FRUI project is a XCode SDK project for UI elements of FRAuth. FRUI requires FRAuth SDK to work with. FRUI SDK currently only supports limited options to customize UI flow, and elements.

### FRExample
FRExample project that contains various types of sample applications that demonstrate usage of FRAuth, and FRUI SDKs. 

## Usage

### 1. Prepare Configuration

#### Using .plist Configuration File
In order to start using SDKs, it is recommended to use `.plist` configuration file to initialize SDK. SDK may also be used without configuration file; however, SDK limits some functionalities when it's not initialized with configuration file, and it's using manual configuration.

SDK consumes `FRAuthConfig.plist` file for configuration which requires following information:

* `forgerock_oauth_client_id`: OAuth2 client's `client_id` registered in OpenAM
* `forgerock_oauth_redirect_uri`: OAuth2 client's `redirect_uri` registered in OpenAM
* `forgerock_oauth_scope`: OAuth2 client's `scope` registered in OpenAM
* `forgerock_oauth_threshold`: Threshold in seconds to refresh OAuth2 token set before `access_token` expires through FRAuth SDK's token management feature. (optional)
* `forgerock_url`: Base URL of OpenAM
* `forgerock_realm`: `realm` in OpenAM
* `forgerock_timeout`: Timeout in seconds of each request that FRAuth SDK communicates to OpenAM. (optional)
* `forgerock_keychain_access_group`: Keychain Access Group Identifier in Xcode's Capabilities tab in the application's target. This is used to share some credentials across multiple applications that are developed under same Apple's Developer Program, and FRAuth SDK utilizes this for SingleSignOn feature. (optional)
* `forgerock_auth_service_name`: Authentication Tree name registered in OpenAM for user authentication.
* `forgerock_registration_service_name`: Authentication Tree name registered in OpenAM for user registration.

See below for sample `FRAuthConfig.plist`:

```
<?xml version="1.0" encoding="UTF-8"?>
<!DOCTYPE plist PUBLIC "-//Apple//DTD PLIST 1.0//EN" "http://www.apple.com/DTDs/PropertyList-1.0.dtd">
<plist version="1.0">
<dict>
	<key>forgerock_oauth_client_id</key>
	<string>iosclient</string>
	<key>forgerock_oauth_redirect_uri</key>
	<string>http://openam.example.com/redirecturi</string>
	<key>forgerock_oauth_scope</key>
	<string>openid profile email address</string>
	<key>forgerock_oauth_url</key>
	<string>http://openam.example.com/openam</string>
	<key>forgerock_oauth_threshold</key>
	<string>60</string>
	<key>forgerock_url</key>
	<string>http://openam.example.com/openam</string>
	<key>forgerock_realm</key>
	<string>root</string>
	<key>forgerock_timeout</key>
	<string>60</string>
	<key>forgerock_keychain_access_group</key>
	<string>com.forgerock.sso</string>
	<key>forgerock_auth_service_name</key>
	<string>UsernamePassword</string>
	<key>forgerock_registration_service_name</key>
	<string>UserSignUp</string>
</dict>
</plist>

```

By default, FRAuth SDK searches for `FRAuthConfig.plist`; however, configuration file name can be customized based on the needs as follows:

```swift
// Set different filename for configuration
FRAuth.configPlistFileName = "CustomConfiguration" // "CustomConfiguration.plist" will be consumed

// Starts SDK
try? FRAuth.start()
```

#### Manual Configuration
In order to start using SDKs manually, ServerConfig and OAuth2Client must be properly configured. These information are essentially being used for SDK to communicate to ForgeRock Platform, or Cloud instances.

OAuth2 client information, such as `client_id`, `redirect_uri`, and `scope` are also required to set-up OAuth2 client in SDK.

##### Create ServerConfig and OAuth2Client

To configure `ServerConfig`, full URL path is required. Realm and timeout options are also available as an optional parameters.

```swift
let url: URL = Server_Url // full URL of OpenAM instance
let redirectUri: URL = Client_Redirect_Uri // redirect_uri registered for OAuth client
	
//	Construct ServerConfig
let serverConfig = ServerConfig(url: url)

// Or configure with "realm" and "timeout"
let serverConfig = ServerConfig(url: url, realm: "root", timeout: 60.0)

//	Construct OAuth2Client with ServerConfig
let oAuth2Config = OAuth2Client(clientId: "client_id", redirectUri: redirectUri, scope: "scope", serverConfig: serverConfig)
```

`ServerConfig` and `OAuth2Client` are required for creating `AuthService` instance which initiates authentication and/or registration flow, and perform OAuth2 protocols for token exchange, or refresh.
