//
//  FRProximity.h
//  FRProximity
//
//  Created by James Go on 10/1/19.
//  Copyright © 2019 James Go. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for FRProximity.
FOUNDATION_EXPORT double FRProximityVersionNumber;

//! Project version string for FRProximity.
FOUNDATION_EXPORT const unsigned char FRProximityVersionString[];

// In this header, you should import all the public headers of your framework using statements like #import <FRProximity/PublicHeader.h>


