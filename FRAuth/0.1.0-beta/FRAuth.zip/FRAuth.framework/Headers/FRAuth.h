//
//  FRAuth.h
//  FRAuth
//
//  Created by James Go on 6/4/19.
//  Copyright © 2019 James Go. All rights reserved.
//

#import <UIKit/UIKit.h>

//! Project version number for FRAuth.
FOUNDATION_EXPORT double FRAuthVersionNumber;

//! Project version string for FRAuth.
FOUNDATION_EXPORT const unsigned char FRAuthVersionString[];

#import "JBUtil.h"
// In this header, you should import all the public headers of your framework using statements like #import <FRAuth/PublicHeader.h>

