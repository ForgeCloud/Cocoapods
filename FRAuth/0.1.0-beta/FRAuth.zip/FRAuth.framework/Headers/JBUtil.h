//
//  JBUtil.h
//  FRAuth
//
//  Created by James Go on 8/6/19.
//  Copyright © 2019 James Go. All rights reserved.
//

#ifndef JBUtil_h
#define JBUtil_h
#include <stdbool.h>

bool validate_dyld(void);
bool validate_sandbox(void);

#endif /* JBUtil_h */
